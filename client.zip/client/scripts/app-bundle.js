define('app',["exports", "aurelia-auth"], function (_exports, _aureliaAuth) {
  "use strict";

  _exports.__esModule = true;
  _exports.App = void 0;

  var App =
  /*#__PURE__*/
  function () {
    function App() {}

    var _proto = App.prototype;

    _proto.configureRouter = function configureRouter(config, router) {
      this.router = router;
      config.addPipelineStep('authorize', _aureliaAuth.AuthorizeStep);
      config.title = 'Things ToDo';
      config.map([{
        route: ['', 'home'],
        name: 'home',
        moduleId: 'modules/home',
        title: 'Home',
        auth: false
      }, {
        route: 'users',
        name: 'users',
        moduleId: 'modules/users',
        title: 'Users',
        auth: true
      }, {
        route: 'todos',
        name: 'todos',
        moduleId: 'modules/todos',
        title: 'Todos',
        auth: true
      }]);
    };

    return App;
  }();

  _exports.App = App;
});;
define('text!app.html',[],function(){return "<template>\n  <nav-bar></nav-bar>\n  <router-view></router-view>\n</template>\n";});;
define('auth-config',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.default = void 0;
  var authConfig = {
    baseUrl: "http://localhost:5000/api",
    loginUrl: '/users/login',
    tokenName: 'token',
    authHeader: 'Authorization',
    authToken: '',
    logoutRedirect: '#/home'
  };
  var _default = authConfig;
  _exports.default = _default;
});;
define('environment',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.default = void 0;
  var _default = {
    debug: true,
    testing: true
  };
  _exports.default = _default;
});;
define('main',["exports", "regenerator-runtime/runtime", "./environment", "./auth-config"], function (_exports, _runtime, _environment, _authConfig) {
  "use strict";

  _exports.__esModule = true;
  _exports.configure = configure;
  _environment = _interopRequireDefault(_environment);
  _authConfig = _interopRequireDefault(_authConfig);

  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

  // regenerator-runtime is to support async/await syntax in ESNext.
  // If you don't use async/await, you can remove regenerator-runtime.
  function configure(aurelia) {
    aurelia.use.standardConfiguration().plugin('aurelia-auth', function (baseConfig) {
      baseConfig.configure(_authConfig.default);
    }).feature('resources');
    aurelia.use.developmentLogging(_environment.default.debug ? 'debug' : 'warn');

    if (_environment.default.testing) {
      aurelia.use.plugin('aurelia-testing');
    }

    aurelia.start().then(function () {
      return aurelia.setRoot();
    });
  }
});;
define('text!modules/components/editUser.html',[],function(){return "<template>\r\n            First Name: <input value.bind=\"user.fname\">\r\n            Last Name: <input value.bind=\"user.lname\">\r\n            Active: <input value.bind=\"user.active\">\r\n            Role: <input value.bind=\"user.role\">\r\n            Email: <input value.bind=\"user.email\">\r\n            Password: <input value.bind=\"user.password\">\r\n            <button click.trigger=\"save()\">Save</button>\r\n        </template>\r\n        ";});;
define('modules/home',["exports", "aurelia-framework", "aurelia-router"], function (_exports, _aureliaFramework, _aureliaRouter) {
  "use strict";

  _exports.__esModule = true;
  _exports.Home = void 0;

  var _dec, _class;

  var Home = (_dec = (0, _aureliaFramework.inject)(_aureliaRouter.Router), _dec(_class =
  /*#__PURE__*/
  function () {
    function Home(router) {
      this.router = router;
      this.message = 'Home';
    }

    var _proto = Home.prototype;

    _proto.login = function login() {
      this.router.navigate('users');
    };

    return Home;
  }()) || _class);
  _exports.Home = Home;
});;
define('text!modules/home.html',[],function(){return "<template>\r\n\t<h1>${message}</h1>\r\n\t<button class=\"btn btn-primary\" click.trigger=\"login()\">Login</button>\r\n</template>\r\n";});;
define('modules/todos',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.Todos = void 0;

  var Todos = function Todos() {};

  _exports.Todos = Todos;
});;
define('text!modules/todos.html',[],function(){return "<template></template>";});;
define('modules/users',["exports", "aurelia-framework", "aurelia-router", "../resources/data/user-object"], function (_exports, _aureliaFramework, _aureliaRouter, _userObject) {
  "use strict";

  _exports.__esModule = true;
  _exports.Users = void 0;

  var _dec, _class;

  var Users = (_dec = (0, _aureliaFramework.inject)(_aureliaRouter.Router, _userObject.User), _dec(_class =
  /*#__PURE__*/
  function () {
    function Users(router, users) {
      this.router = router;
      this.users = users;
      this.message = 'Users';
    }

    var _proto = Users.prototype;

    _proto.newUser = function newUser() {
      this.user = {
        firstName: "",
        lastName: "",
        active: true,
        role: "user",
        email: "",
        password: ""
      };
    };

    _proto.save = function save() {
      return regeneratorRuntime.async(function save$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              if (!(this.user && this.user.fname && this.user.lname && this.user.email && this.user.password)) {
                _context.next = 3;
                break;
              }

              _context.next = 3;
              return regeneratorRuntime.awrap(this.users.saveUser(this.user));

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, null, this);
    };

    _proto.logout = function logout() {
      this.router.navigate('home');
    };

    return Users;
  }()) || _class);
  _exports.Users = Users;
});;
define('text!modules/users.html',[],function(){return "<template>\r\n        <h1>${message}</h1>\r\n        <button click.trigger=\"newUser()\">New User</button>\r\n         <compose view=\"./components/editUser.html\">\u000b </compose>\r\n</template>";});;
define('resources/data/data-services',["exports", "aurelia-framework", "aurelia-fetch-client"], function (_exports, _aureliaFramework, _aureliaFetchClient) {
  "use strict";

  _exports.__esModule = true;
  _exports.DataServices = void 0;

  var _dec, _class;

  var DataServices = (_dec = (0, _aureliaFramework.inject)(_aureliaFetchClient.HttpClient), _dec(_class =
  /*#__PURE__*/
  function () {
    function DataServices(http) {
      var _this = this;

      this.httpClient = http;
      this.BASE_URL = "http://localhost:5000/api/";
      this.httpClient.configure(function (config) {
        config.withBaseUrl(_this.BASE_URL).withDefaults({
          credentials: 'same-origin',
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'Fetch',
            'Authorization': 'Bearer' + localStorage.getItem('aurelia_token')
          }
        }).withInterceptor({
          request: function request(_request) {
            console.log('Requesting ${request.method} ${request.url}');
            return _request;
          },
          response: function response(_response) {
            console.log('Received ${response.status} ${response.url}');
            return _response;
          }
        });
      });
    }

    var _proto = DataServices.prototype;

    _proto.get = function get(url) {
      return this.httpClient.fetch(url).then(function (response) {
        return response.json();
      }).then(function (data) {
        return data;
      }).catch(function (error) {
        return error;
      });
    };

    _proto.post = function post(content, url) {
      return this.httpClient.fetch(url, {
        method: 'post',
        body: (0, _aureliaFetchClient.json)(content)
      }).then(function (response) {
        return response.json();
      }).then(function (object) {
        return object;
      }).catch(function (error) {
        return error;
      });
    };

    _proto.put = function put(content, url) {
      return this.httpClient.fetch(url, {
        method: 'put',
        body: (0, _aureliaFetchClient.json)(content)
      }).then(function (response) {
        return response.json();
      }).then(function (object) {
        return object;
      }).catch(function (error) {
        return error;
      });
    };

    _proto.delete = function _delete(url) {
      return this.httpClient.fetch(url, {
        method: 'delete'
      }).then(function (response) {
        return response.json();
      }).then(function (object) {
        return object;
      }).catch(function (error) {
        return error;
      });
    };

    return DataServices;
  }()) || _class);
  _exports.DataServices = DataServices;
});;
define('resources/data/user-object',["exports", "aurelia-framework", "./data-services"], function (_exports, _aureliaFramework, _dataServices) {
  "use strict";

  _exports.__esModule = true;
  _exports.User = void 0;

  var _dec, _class;

  var User = (_dec = (0, _aureliaFramework.inject)(_dataServices.DataServices), _dec(_class =
  /*#__PURE__*/
  function () {
    function User(data) {
      this.data = data;
      this.USER_SERVICE = 'users';
    }

    var _proto = User.prototype;

    _proto.saveUser = function saveUser(user) {
      var serverResponse;
      return regeneratorRuntime.async(function saveUser$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              if (!user) {
                _context.next = 5;
                break;
              }

              _context.next = 3;
              return regeneratorRuntime.awrap(this.data.post(user, this.USER_SERVICE));

            case 3:
              serverResponse = _context.sent;
              return _context.abrupt("return", serverResponse);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, null, this);
    };

    return User;
  }()) || _class);
  _exports.User = User;
});;
define('resources/elements/nav-bar',["exports", "aurelia-framework", "aurelia-router", "aurelia-auth"], function (_exports, _aureliaFramework, _aureliaRouter, _aureliaAuth) {
  "use strict";

  _exports.__esModule = true;
  _exports.NavBar = void 0;

  var _dec, _class;

  var NavBar = (_dec = (0, _aureliaFramework.inject)(_aureliaRouter.Router, _aureliaAuth.AuthService), _dec(_class =
  /*#__PURE__*/
  function () {
    function NavBar(router, auth) {
      this.authenticated = false;
      this.router = router;
      this.auth = auth;
      this.loginError = '';
      this.email = "";
      this.password = "";
    }

    var _proto = NavBar.prototype;

    _proto.attached = function attached() {
      $('.navbar-nav a').on('click', function () {
        $('.navbar-nav').find('li.active').removeClass('active');
        $(this).parent('li').addClass('active');
      });
    };

    _proto.login = function login() {
      var _this = this;

      //   console.log(this.email);
      //   console.log(this.password);
      this.authenticated = true;
      this.router.navigate('home');
      return this.auth.login(this.email, this.password).then(function (response) {
        _this.userObj = response.user;
        sessionStorage.setItem("userObj", JSON.stringify(_this.userObj));
        _this.loginError = "";
        _this.authenticated = _this.auth.isAuthenticated();

        _this.router.navigate('home');
      }).catch(function (error) {
        console.log(error);
        _this.authenticated = false;
        _this.loginError = "Invalid credentials.";
      });
    };

    _proto.bind = function bind() {
      this.authenticated = this.auth.isAuthenticated();
    };

    _proto.logout = function logout() {
      // this.authenticated = false;
      //  this.router.navigate('landing');
      this.auth.logout();
      sessionStorage.removeItem('userObj');
      this.authenticated = this.auth.isAuthenticated();
    };

    return NavBar;
  }()) || _class);
  _exports.NavBar = NavBar;
});;
define('text!resources/elements/nav-bar.html',[],function(){return "<template>\r\n      <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\r\n            <a class=\"navbar-brand\" href=\"#\">Things Todo</a>\r\n            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\"\r\n                  aria-controls=\"navbarSupportedContent\"  aria-expanded=\"false\"  aria-label=\"Toggle navigation\">\r\n                  <span class=\"navbar-toggler-icon\"></span>\r\n                </button>\r\n            <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\r\n                  <ul show.bind=\"authenticated\" class=\"navbar-nav mr-auto\">\r\n                        <li class=\"nav-item active\">\r\n                              <a class=\"nav-link\" href=\"#users\">Users <span class=\"sr-only\">(current)</span></a>\r\n                            </li>\r\n                        <li class=\"nav-item\">\r\n                              <a class=\"nav-link\" href=\"#todos\">Todos</a>\r\n                            </li>\r\n                        <li class=\"nav-item\">\r\n                              <a class=\"nav-link\" href=\"#\" click.trigger=\"logout()\">Logout</a>\r\n                            </li>\r\n                      </ul>\r\n            <div show.bind=\"!authenticated\">\r\n                <form class=\"form-inline\">\r\n                    <div class=\"form-group mb-2\">\r\n                        <label for=\"staticEmail2\" class=\"sr-only\">Email</label>\r\n                        <input value.bind=\"email\" type=\"text\" readonly class=\"form-control\" id=\"staticEmail2\"\r\n                            value=\"email@example.com\">\r\n                    </div>\r\n                    <div class=\"form-group mx-sm-3 mb-2\">\r\n                        <label for=\"inputPassword2\" class=\"sr-only\">Password</label>\r\n                        <input value.bind=\"password\" type=\"password\" class=\"form-control\" id=\"inputPassword2\"\r\n                            placeholder=\"Password\">\r\n                    </div>\r\n                    <button type=\"submit\" click.trigger=\"login()\" class=\"btn btn-primary mb-2\">Confirm identity</button>\r\n                    <span style=\"margin-left: 20px;\" show.bind=\"loginError\">${loginError}</span>\r\n                </form>\r\n            </div>    \r\n        </div>\r\n          </nav>\r\n</template>";});;
define('resources/index',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.configure = configure;

  function configure(config) {
    config.globalResources(['./elements/nav-bar']);
  }
});;
define('resources',['resources/index'],function(m){return m;});
//# sourceMappingURL=app-bundle.js.map