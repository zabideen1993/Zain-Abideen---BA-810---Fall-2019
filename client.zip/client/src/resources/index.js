export function configure(config) {
  config.globalResources([
   './elements/nav-bar'
  ]);
}
